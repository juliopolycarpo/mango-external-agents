import json
import subprocess
import sys
import time
from pathlib import Path

child = subprocess.Popen([sys.executable, '-c', 'import time; time.sleep(60)',
                          'MANGO_FAKE_BUILD_CHILD'])
Path(sys.argv[1]).write_text(json.dumps({'pid': child.pid}))
time.sleep(60)
