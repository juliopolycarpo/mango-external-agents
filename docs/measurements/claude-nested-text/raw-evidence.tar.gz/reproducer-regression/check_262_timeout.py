import hashlib
import importlib.util
import json
import os
import signal
import sys
import time
import threading
from pathlib import Path

source = Path(sys.argv[1])
side = sys.argv[2]
root = Path('/workspace/work/pr-wave')
out = root / ('perf-262-timeout-' + side)
out.mkdir()
spec = importlib.util.spec_from_file_location('allocation_reproducer_under_test', source)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.EVIDENCE = out
module.AUDIT = out / 'attempts.jsonl'
pidfile = out / 'child.json'
timer = None
try:
    if side.startswith('interrupted'):
        timer = threading.Timer(0.3, lambda: os.kill(os.getpid(), signal.SIGINT))
        timer.start()
    module.command('fake-build-timeout', [sys.executable, str(root / 'fake-build-parent.py'),
                   str(pidfile)], out, timeout=10 if timer else 0.5)
    raise RuntimeError('expected a command timeout or interruption')
except AssertionError:
    assert not side.startswith('interrupted')
except KeyboardInterrupt:
    assert side.startswith('interrupted')
finally:
    if timer:
        timer.cancel()
pid = json.loads(pidfile.read_text())['pid']
stat = Path(f'/proc/{pid}/stat')
state = stat.read_text().split(') ', 1)[1].split()[0] if stat.exists() else 'gone'
running = state not in ['gone', 'Z', 'X']
record = {'source': str(source), 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
          'child_pid': pid, 'state_after_timeout': state, 'child_still_running': running,
          'expected_running_on_old': side == 'old'}
if running:
    # This is the exact test-owned child published by FakeBuildParent, not a searched process.
    assert b'MANGO_FAKE_BUILD_CHILD' in Path(f'/proc/{pid}/cmdline').read_bytes()
    os.kill(pid, signal.SIGKILL)
    record['test_cleanup'] = 'killed exact owned fake child'
(out / 'proof.json').write_text(json.dumps(record, indent=2) + '\n')
assert running == (side == 'old'), record
print(json.dumps(record), flush=True)
